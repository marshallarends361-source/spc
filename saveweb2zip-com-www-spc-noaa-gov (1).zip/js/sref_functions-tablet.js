/*/////////==================================================///////////
///------------------------------------------------------------------///
/// This was originally based off the  California-Nevada River       ///
/// Forecast Center (http://www.cnrfc.noaa.gov) Image Looper.        ///
///------------------------------------------------------------------///
/// Significant Modifications made by Joe Young of the Oklahoma      ///
/// Weather Lab - HOOT Project (http://hoot.metr.ou.edu).            ///
/// Januray 2008                                                     ///
///                                                                  ///
/// More Modifications made by Joe Young for the HOOT Project        ///
/// February 2009                                                    ///
///__________________________________________________________________///
/// Modified 02/12 for application with SPC SREF page.               ///
///==================================================================///
///////// PLEASE KEEP THIS REFERENCE INTACT FOR USE             ////////
//////////////////////////////////////////////////////////////////////*/
 
var inc = 2, delay = 500, dinc = 100, dwell = 1000;
var num_loaded_images = 0;
var frame=-1;
var timeout_id=null;
var dir=1;  
var playing = 0;
var run = 0;
 
// function to count images as they are loaded into cache
function count_images()
{
        if (++num_loaded_images == window.imax) {
                /// this is where we define wether or not to start looping
                /// once images are loaded.
                if (!window.pauseOnStart) animate();
                else step(window.pauseWhere);
                //hideLoadBox();
                show_delay();
                show_dwell();
                forward();
        }  else 
        {
                document.animation.src=images[num_loaded_images-1].src;
                document.form.frame.value=num_loaded_images+" of "+window.imax;
                //showLoadBox(); 
        }
}



// actual loading is done here
function initialize_looper()
{
        images = new Array(window.imax);
        for (var i = 0 ; i < window.imax; i++) {
         images[i]= new Image();
         images[i].onload=count_images;
         images[i].src=window.temp_list[i];
         if (images[i].height == null) {i-=1;}
        }
    
        // call the functions to initialize the values of the displays
 
        show_delay();
        show_dwell();
}   
// function to start movie
    
function start_play() {
 if (playing == 0) {
  if (timeout_id == null && num_loaded_images==window.imax) animate();
 }
} 

// function to stop movie
 
function stop_play() {
 if (timeout_id) clearTimeout(timeout_id);
  timeout_id=null;
  playing = 0;
} 

// function to do the animation when all images are loaded

function animate()
{
 var controlDelay;
 frame=(frame+dir+window.imax)%window.imax;
 j=frame+1;
 if ((j == window.imax || j == 1) && document.form.dwell.checked) {controlDelay = dwell;} else {controlDelay = delay; }
 if ((j == 1 || j == window.imax) && document.form.rock.checked) dir = -dir;
 if (images[frame].height) {document.animation.src=images[frame].src;} else {images[i].src=window.temp_list[frame];document.animation.src=images[window.temp_list].src;}
 document.form.frame.value=j+" of "+window.imax;
 timeout_id=setTimeout("animate()",controlDelay);
 playing=1;
}


// function to control stepping thru each frame

function step(frm,click)
{
 if (frm == null) {

    if (timeout_id) clearTimeout(timeout_id); timeout_id=null;
    frame=(frame+dir+window.imax)%window.imax;
    j=frame+1;
    document.animation.src=images[frame].src;
    document.form.frame.value=j+" of "+window.imax;
 } else if (document.form.nostep.checked || click != null){

    if (timeout_id) clearTimeout(timeout_id); timeout_id=null;
    frame=frm;
    j=frm+1;
    document.animation.src=images[frm].src;
    document.form.frame.value=j+" of "+window.imax;
 }
 playing=0;
}
function forwardstep()
{
 if (timeout_id) clearTimeout(timeout_id); timeout_id=null;
 frame=(frame+dir+window.imax)%window.imax;
 j=frame+1;
 document.animation.src=images[frame].src;
 document.form.frame.value=j+" of "+window.imax;
 playing=0;
}
function backstep()
{
 if (timeout_id) clearTimeout(timeout_id); timeout_id=null;
 frame=(frame-dir+window.imax)%window.imax;
 j=frame+1;
 document.animation.src=images[frame].src;
 document.form.frame.value=j+" of "+window.imax;
 playing=0;
}

// functions to control direction of animation

function reverse()
{
 if (dir < 0) dir = dir;
 if (dir > 0) dir=-dir;
 loop=1;
}

function forward()
{
 if (dir < 0) dir = -dir;
 if (dir > 0) dir = dir;
 loop=1;
}

function loop()
{
  loop="yes";
}

// function to display delay between frames

function show_delay()
{
var dely;

dely  = 1/(delay/1000);
dely = Math.round(dely*10)/10;
document.form.dly.value=dely;
}
function incDwell()
{
        dwell = dwell + dinc;
}

function decDwell()
{
        if (dwell > 0) {dwell = dwell - dinc; }
}

function show_dwell(typ)
{
        var dwel = dwell/1000;
        if (typ !=null)
        {
                if (document.form.dwell.checked)
                {
                        document.form.dwell.checked=false;
                }
                else
                {
                        document.form.dwell.checked=true;
                }
        }

        if (document.form.dwell.checked)
        {
                document.form.dwl.value=dwel;
        } else
        {
                document.form.dwl.value=null;
        }

}

function showLoadBox()
{
        document.getElementById("loadingBox").style.display="block";
}
function hideLoadBox()
{
        document.getElementById("loadingBox").style.display="none";
}


// Function for displaying help box

function open_key()
{
window.open("key_help.html","SPC SREF keyboard commands","location=0,width=340,height=220,left=0,top=200");
}

// Function for displaying product and map overlays

function changeOverlay()
{
        var cwas = document.getElementById("cwa_ovly");
        var city = document.getElementById("city_ovly");
        var road = document.getElementById("road_ovly");
        var artcc = document.getElementById("artcc_ovly");
        var dy1ac = document.getElementById("dy1ac_ovly");
        var dy2ac = document.getElementById("dy2ac_ovly");
        var dy3ac = document.getElementById("dy3ac_ovly");
        var dy1fire = document.getElementById("dy1fire_ovly");
        var dy2fire = document.getElementById("dy2fire_ovly");
        if (cwas.checked)  { document.getElementById("bgcwa").className="shown"; }  else { document.getElementById("bgcwa").className="hidden"; }
        if (city.checked)  { document.getElementById("bgcity").className="shown"; }  else { document.getElementById("bgcity").className="hidden"; }
        if (road.checked)  { document.getElementById("bgroad").className="shown"; }  else { document.getElementById("bgroad").className="hidden"; }
        if (artcc.checked)  { document.getElementById("bgartcc").className="shown"; }  else { document.getElementById("bgartcc").className="hidden"; }
        if (dy1ac.checked)  { document.getElementById("bgdy1ac").className="shown"; }  else { document.getElementById("bgdy1ac").className="hidden"; }
        if (dy2ac.checked)  { document.getElementById("bgdy2ac").className="shown"; }  else { document.getElementById("bgdy2ac").className="hidden"; }
        if (dy3ac.checked)  { document.getElementById("bgdy3ac").className="shown"; }  else { document.getElementById("bgdy3ac").className="hidden"; }
        if (dy1fire.checked)  { document.getElementById("bgdy1fire").className="shown"; }  else { document.getElementById("bgdy1fire").className="hidden"; }
        if (dy2fire.checked)  { document.getElementById("bgdy2fire").className="shown"; }  else { document.getElementById("bgdy2fire").className="hidden"; }
}

// Function for product menu

// Copyright 2006-2007 javascript-array.com
//var timeout     = 5000;
var timeout     = 60000;
var closetimer  = 0;
var ddmenuitem  = 0;

// open hidden layer
function mopen(id)
{
        // cancel close timer
        mcancelclosetime();

        // close old layer
        if(ddmenuitem) ddmenuitem.style.visibility = 'hidden';

        // get new layer and show it
        ddmenuitem = document.getElementById(id);
        ddmenuitem.style.visibility = 'visible';
        ddmenuitem.style.zIndex = 30;

}

// close showed layer
function mclose()
{
        if(ddmenuitem) ddmenuitem.style.visibility = 'hidden';
}

// go close timer
function mclosetime()
{
        closetimer = window.setTimeout(mclose, timeout);
}

// cancel close timer
function mcancelclosetime()
{
        if(closetimer)
        {
                window.clearTimeout(closetimer);
                closetimer = null;
        }
}

// close layer when click-out
// This must be commented out, otherwise, onclick calls does not work.  Jay Liang, Fri Mar 30 19:47:27 UTC 2012
// document.onclick = mclose;
// document.onmouseout = mclosetime;
document.onclick = mclosetime;
 
