(() => {
    'use strict';

    const BANNER_ID = 'sref-sunset-banner';
    const DISMISSED_KEY = 'sref-sunset-banner-dismissed';

    function wasDismissed() {
        try {
            return window.sessionStorage.getItem(DISMISSED_KEY) === 'true';
        } catch {
            return false;
        }
    }

    function initBanner() {
        // Avoid duplicate banners or showing it again after dismissal.
        if (document.getElementById(BANNER_ID) || wasDismissed()) return;

        const banner = document.createElement('aside');
        banner.id = BANNER_ID;
        banner.className = 'sref-sunset-banner';
        banner.setAttribute('role', 'region');
        banner.setAttribute('aria-label', 'SREF retirement notice');

        banner.innerHTML = `
            <div class="sref-sunset-banner__content">
                <div class="sref-sunset-banner__message">
                    <strong>NOTICE</strong>
                    <p>
                        The Short-Range Ensemble Forecast (SREF) is scheduled for
                        retirement by the NWS on or about October 6, 2026.
                    </p>
                    <p>
                        More information is available in the
                        <a
                            href="https://www.weather.gov/media/notification/pdf_2026/scn26-48_updated_RRFS_and_REFS_Implementation_aac.pdf"
                            target="_blank"
                            rel="noopener noreferrer"
                        >Service Change Notice (SCN)</a>
                        formally announcing the SREF retirement.
                    </p>
                    <p>
                        Because this page relies on SREF data, it will be sunset
                        in coordination with the SREF retirement. A link to the
                        formal announcement will be added once the official date
                        is finalized.
                    </p>
                </div>

                <button
                    type="button"
                    class="sref-sunset-banner__close"
                    aria-label="Close SREF retirement notice"
                >&times;</button>
            </div>
        `;

        const styles = document.createElement('style');
        styles.textContent = `
            #${BANNER_ID} {
                box-sizing: border-box;
                width: 100%;
                max-height: 1000px;
                overflow: hidden;
                background: #fff3cd;
                border-bottom: 2px solid #ffeeba;
                color: #856404;
                opacity: 1;
                transition:
                    max-height 400ms ease,
                    opacity 400ms ease;
            }

            #${BANNER_ID}.is-closing {
                max-height: 0;
                opacity: 0;
            }

            #${BANNER_ID} .sref-sunset-banner__content {
                position: relative;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 12px 55px 12px 20px;
                font: 14px/1.45 system-ui, sans-serif;
                text-align: center;
            }

            #${BANNER_ID} .sref-sunset-banner__message {
                max-width: 1000px;
            }

            #${BANNER_ID} strong {
                display: block;
                margin-bottom: 4px;
                font-size: 22px;
            }

            #${BANNER_ID} p {
                margin: 4px 0;
            }

            #${BANNER_ID} a {
                color: inherit;
                font-weight: 600;
            }

            #${BANNER_ID} .sref-sunset-banner__close {
                position: absolute;
                top: 50%;
                right: 15px;
                transform: translateY(-50%);
                padding: 4px 8px;
                border: 0;
                background: transparent;
                color: inherit;
                cursor: pointer;
                font-size: 26px;
                line-height: 1;
            }

            #${BANNER_ID} .sref-sunset-banner__close:focus-visible {
                outline: 2px solid currentColor;
                outline-offset: 2px;
            }

            @media (prefers-reduced-motion: reduce) {
                #${BANNER_ID} {
                    transition: none;
                }
            }
        `;

        document.head.appendChild(styles);
        document.body.prepend(banner);

        banner.querySelector('.sref-sunset-banner__close')
            .addEventListener('click', () => {
                try {
                    window.sessionStorage.setItem(DISMISSED_KEY, 'true');
                } catch {
                    // Continue closing if browser storage is unavailable.
                }

                banner.classList.add('is-closing');

                banner.addEventListener(
                    'transitionend',
                    () => {
                        banner.remove();
                        styles.remove();
                    },
                    { once: true }
                );
            });
    }

    if (document.body) {
        initBanner();
    } else {
        document.addEventListener('DOMContentLoaded', initBanner, { once: true });
    }
})();
